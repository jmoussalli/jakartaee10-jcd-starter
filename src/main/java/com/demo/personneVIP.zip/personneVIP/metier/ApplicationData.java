package com.demo.personneVIP.metier;

public class ApplicationData {

    public static Annuaire annuaire = new Annuaire();


}
